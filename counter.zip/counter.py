from flask import Flask, render_template, session, redirect, request, url_for
app = Flask(__name__)
app.secret_key = 'secretkey'
@app.route('/')
def index():
    if 'increment_redirect' in session:
        session.pop('increment_redirect', None)
    else:
        if 'counter' in session:
            session['counter'] += 1
        else:
            session['counter'] = 1  
    return render_template('counter.html', counter = session['counter'])



@app.route('/destroy', methods = ['POST'])
def destroy():
    session.pop('counter', None)
    return redirect(url_for('index'))


@app.route('/increment_by_two', methods=['POST'])
def increment_by_two():
    if 'counter' in session:
        session['counter'] += 2
    else:
        session['counter'] = 2  

    session['increment_redirect'] = True
    return redirect(url_for('index'))


@app.route('/customize', methods = ['POST'],)
def customize():
    customize = int(request.form.get('increment', 1))
    if 'counter' in session:
        session['counter'] += customize
    else:
        session['counter'] = customize
    session['increment_redirect'] = True
    return redirect (url_for('index'))




if __name__=="__main__":
    app.run(debug=True)
